from replit_ffmpeg.installer import main

main()
