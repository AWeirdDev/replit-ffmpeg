# replit-ffmpeg

A simple tool for installing ffmpeg, libopus (opus) and youtube dl (optional) for you on Replit.

```bash
$ pip install replit-ffmpeg
```

To use it, simply run this in your terminal:

```bash
$ replit-ffmpeg
```

That's about it. Enjoy your "FFmpeg." Yup, it sounds weird.
