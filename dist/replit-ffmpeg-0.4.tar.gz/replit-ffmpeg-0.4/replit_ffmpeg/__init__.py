from .installer import main

__all__ = (
    'main',
)